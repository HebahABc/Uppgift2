import {createContext } from 'react';
export const productContext = createContext();
export const FeaturedProductsContext = createContext()
export const GridProductsContext = createContext()



