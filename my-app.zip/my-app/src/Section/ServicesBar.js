import React from 'react'

const ServicesBar = () => {
  return (
    <div className="_FlexBox_2">
            <div id="support">
                <div id="img5">
                </div>
                <h4>Customer Support</h4>
                <p>Village did removed enjoyed explain talking.</p>
            </div>
            <div id="payment">
                <div id="img6">
                </div>
                <h4>Customer Support</h4>
                <p>Village did removed enjoyed explain talking.</p>
            </div>
            <div id="delivery">
                <div id="img7">
                </div>
                <h4>Customer Support</h4>
                <p>Village did removed enjoyed explain talking.</p>
            </div>
            <div id="returs">
                <div id="img7">
                </div>
                <h4>Customer Support</h4>
                <p>Village did removed enjoyed explain talking.</p>
            </div>
        </div>
  )
}

export default ServicesBar