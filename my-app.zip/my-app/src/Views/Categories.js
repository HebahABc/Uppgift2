import React from 'react'
import CurrentPage from '../Components/CurrentPage'


function Categories () {
  window.top.document.title = 'Categories | Fixxo.'
  return (
    <>
    <CurrentPage cpage=' Categories'/>
    </>
  )
}

export default Categories