import React from 'react'

const WishList = () => {
  window.top.document.title = 'Wish List | Fixxo.'
  return (
    <></>
  )
}

export default WishList