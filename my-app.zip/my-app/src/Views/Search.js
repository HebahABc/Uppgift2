import React from 'react'

const Search = () => {
  window.top.document.title = 'Search | Fixxo.'
  return (
    <div>
    </div>
  )
}

export default Search