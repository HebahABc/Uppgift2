import React from 'react'

const Compare = () => {
  window.top.document.title = 'Compare items | Fixxo.'
  return (
    <div>
    </div>
  )
}

export default Compare